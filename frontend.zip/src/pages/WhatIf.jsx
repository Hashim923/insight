import React, { useState, useEffect } from 'react';
import axios from 'axios';
import HeatMap from '../components/HeatMap';
import EfficiencyCard from '../components/EfficiencyCard';

const WhatIf = () => {
    const [subjects, setSubjects] = useState([]);
    const [adjustments, setAdjustments] = useState({}); // { SubjectName: { addedExams: [], addedHours: 0 } }
    const [result, setResult] = useState(null);

    useEffect(() => {
        // Fetch subjects to populate dropdown
        axios.get('http://localhost:5001/api/data/subjects')
            .then(res => setSubjects(res.data))
            .catch(err => console.error(err));
    }, []);

    const handleAddExam = (subjectName, marks) => {
        const currentadj = adjustments[subjectName] || { addedExams: [], addedHours: 0 };
        currentadj.addedExams.push({ marks: Number(marks) });
        setAdjustments({ ...adjustments, [subjectName]: currentadj });
    };

    const handleAddHours = (subjectName, hours) => {
        const currentadj = adjustments[subjectName] || { addedExams: [], addedHours: 0 };
        currentadj.addedHours += Number(hours);
        setAdjustments({ ...adjustments, [subjectName]: currentadj });
    };

    const runSimulation = async () => {
        // Convert adjustments map to array for backend
        const adjustmentsList = Object.keys(adjustments).map(key => ({
            subjectName: key,
            addedExams: adjustments[key].addedExams,
            addedHours: adjustments[key].addedHours
        }));

        try {
            const res = await axios.post('http://localhost:5001/api/analytics/what-if', { adjustments: adjustmentsList });
            setResult(res.data);
        } catch (err) {
            console.error(err);
            alert("Simulation failed");
        }
    };

    const [selectedSubject, setSelectedSubject] = useState('');
    const [tempMarks, setTempMarks] = useState('');
    const [tempHours, setTempHours] = useState('');

    return (
        <div className="container">
            <h2>What-If Scenario Planner</h2>
            <p className="text-secondary">Simulate outcomes without saving to database.</p>

            <div className="card" style={{ marginBottom: '20px' }}>
                <h3>Add Hypothetical Data</h3>
                <div className="input-group">
                    <label>Subject</label>
                    <select value={selectedSubject} onChange={e => setSelectedSubject(e.target.value)}>
                        <option value="">Select Subject</option>
                        {subjects.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                    </select>
                </div>

                <div style={{ display: 'flex', gap: '20px' }}>
                    <div className="input-group" style={{ flex: 1 }}>
                        <label>Add Hypothetical Exam Marks (0-100)</label>
                        <input type="number" value={tempMarks} onChange={e => setTempMarks(e.target.value)} />
                        <button className="btn btn-primary" style={{ marginTop: '10px' }}
                            onClick={() => {
                                if (selectedSubject && tempMarks) {
                                    handleAddExam(selectedSubject, tempMarks);
                                    setTempMarks('');
                                }
                            }}>
                            Add Exam
                        </button>
                    </div>

                    <div className="input-group" style={{ flex: 1 }}>
                        <label>Add Study Hours</label>
                        <input type="number" value={tempHours} onChange={e => setTempHours(e.target.value)} />
                        <button className="btn btn-primary" style={{ marginTop: '10px' }}
                            onClick={() => {
                                if (selectedSubject && tempHours) {
                                    handleAddHours(selectedSubject, tempHours);
                                    setTempHours('');
                                }
                            }}>
                            Add Hours
                        </button>
                    </div>
                </div>

                <div style={{ marginTop: '20px' }}>
                    <strong>Planned Adjustments:</strong>
                    <pre style={{ background: '#f8f9fa', padding: '10px', borderRadius: '4px' }}>
                        {JSON.stringify(adjustments, null, 2)}
                    </pre>
                </div>

                <button className="btn btn-primary" style={{ width: '100%', marginTop: '20px' }} onClick={runSimulation}>
                    RUN SIMULATION
                </button>
            </div>

            {result && (
                <div style={{ border: '2px dashed #f39c12', padding: '20px', borderRadius: '8px' }}>
                    <h3 className="text-warning">HYPOTHETICAL RESULTS</h3>
                    <p>{result.disclaimer}</p>

                    <div className="dashboard-grid">
                        <HeatMap subjects={result.insights} />
                        {result.insights.filter(s => adjustments[s.subject]).map(sub => (
                            <div key={sub.subject} className="card">
                                <strong>{sub.subject} (Simulated)</strong>
                                <EfficiencyCard
                                    subject={sub.subject}
                                    efficiency={sub.efficiency}
                                    average={sub.average}
                                    trend={sub.trend}
                                />
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default WhatIf;
