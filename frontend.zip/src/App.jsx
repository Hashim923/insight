import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import WhatIf from './pages/WhatIf';

function NavLink({ to, children }) {
    const location = useLocation();
    const isActive = location.pathname === to;
    return (
        <Link to={to} className={isActive ? 'active' : ''}>
            {children}
        </Link>
    );
}

function App() {
    return (
        <Router>
            <div className="container">
                <header>
                    <h1>ACADEMIC INSIGHT DASHBOARD</h1>
                    <nav>
                        <NavLink to="/">Dashboard</NavLink>
                        <NavLink to="/what-if">What-If Planner</NavLink>
                    </nav>
                </header>

                <main>
                    <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/what-if" element={<WhatIf />} />
                    </Routes>
                </main>
            </div>
        </Router>
    );
}

export default App;
