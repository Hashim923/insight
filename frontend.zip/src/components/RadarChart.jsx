import React from 'react';
import { Radar } from 'react-chartjs-2';

const RadarChart = ({ subjects }) => {
    // subjects expected: Array of subject objects with { name, average, consistency, efficiency }

    if (!subjects || subjects.length === 0) return <div>No data for Radar Chart</div>;

    const data = {
        labels: ['Average Marks', 'Consistency', 'Efficiency (x10)'],
        // Efficiency is usually small (marks/hour e.g., 60/10 = 6). Scaling up for visibility against 0-100 scales.

        datasets: subjects.map((sub, index) => {
            const colors = [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
            ];
            const borderColors = [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
            ];

            return {
                label: sub.subject,
                data: [sub.average, sub.consistency, sub.efficiency * 10], // Scaling efficiency
                backgroundColor: colors[index % colors.length],
                borderColor: borderColors[index % borderColors.length],
                borderWidth: 1,
            };
        }),
    };

    const options = {
        responsive: true,
        scales: {
            r: {
                angleLines: {
                    display: false
                },
                suggestedMin: 0,
                suggestedMax: 100
            }
        }
    };

    return <Radar data={data} options={options} />;
};

export default RadarChart;
