import React from 'react';
import { Line } from 'react-chartjs-2';

const TrendChart = ({ data, title }) => {
    // data expected: { labels: ['Exam 1', 'Exam 2'], values: [60, 75] }

    const chartData = {
        labels: data.labels,
        datasets: [
            {
                label: title || 'Marks Trend',
                data: data.values,
                fill: false,
                borderColor: '#3498db',
                tension: 0.1
            }
        ]
    };

    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: !!title,
                text: title,
            },
        },
        scales: {
            y: {
                beginAtZero: true,
                max: 100 // Assuming percentage
            }
        }
    };

    return <Line data={chartData} options={options} />;
};

export default TrendChart;
