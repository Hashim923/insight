import React from 'react';

const HeatMap = ({ subjects }) => {
    // subjects: [{ subject: 'Math', isWeak: true, average: 60 }, ...]

    if (!subjects) return null;

    return (
        <div className="card">
            <h3>Academic Heatmap (Weakness Detection)</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))', gap: '10px' }}>
                {subjects.map((sub) => (
                    <div
                        key={sub.subject}
                        style={{
                            padding: '15px',
                            textAlign: 'center',
                            backgroundColor: sub.isWeak ? '#ffebee' : '#e8f5e9',
                            border: sub.isWeak ? '1px solid #ffcdd2' : '1px solid #c8e6c9',
                            borderRadius: '4px'
                        }}
                    >
                        <strong style={{ display: 'block', marginBottom: '5px' }}>{sub.subject}</strong>
                        <span style={{ color: sub.isWeak ? '#c62828' : '#2e7d32', fontWeight: 'bold' }}>
                            {Number(sub.average).toFixed(0)}%
                        </span>
                        {sub.isWeak && <div style={{ fontSize: '0.7em', color: '#c0392b', marginTop: '5px' }}>NEEDS ATTENTION</div>}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default HeatMap;
