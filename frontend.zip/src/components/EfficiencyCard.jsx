import React from 'react';

const EfficiencyCard = ({ subject, efficiency, average, trend }) => {
    let trendColor = 'text-secondary';
    if (trend === 'Improving') trendColor = 'text-success';
    else if (trend === 'Declining') trendColor = 'text-danger';

    return (
        <div className="card efficiency-card">
            <h3>{subject}</h3>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <p className="text-secondary" style={{ fontSize: '0.9rem', margin: '0 0 5px 0' }}>ROI (Marks/Hour)</p>
                    <p style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: 0 }}>{efficiency}</p>
                </div>
                <div style={{ textAlign: 'right' }}>
                    <p style={{ margin: 0 }}>Avg: {Number(average).toFixed(1)}%</p>
                    <p className={trendColor} style={{ fontWeight: 600, margin: '5px 0 0 0' }}>{trend}</p>
                </div>
            </div>
        </div>
    );
};

export default EfficiencyCard;
